package Constants;

public enum Cities {
    PREHENSILE{
        @Override
        public String toString() {
            return "Prehensile";
        }
    },

    DAVILON{
        @Override
        public String toString() {
            return "Davilon";
        }
    },

    GREENBERG{
        @Override
        public String toString() {
            return "Greenberg";
        }
    },

    SAN_MOSQUITO{
        @Override
        public String toString() {
            return "San Mosquito";
        }
    },

    PANOPTICON{
        @Override
        public String toString() {
            return "Panopticon";
        }
    }
}

