package Actions;

public interface Name {
    default String getName() {
        return null;
    }
}
