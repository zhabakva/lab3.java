package Actions;

public interface Error {
    static String getError() {
        return null;
    }
}
