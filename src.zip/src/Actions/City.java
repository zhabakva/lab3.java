package Actions;

import Constants.*;

public interface City {
    default Cities getCity() {
        return null;
    }
}
