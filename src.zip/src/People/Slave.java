package People;

import Constants.*;


public class Slave extends Human {
    public Slave(String name,  Cities city) {
        super(name, city);
    }
    public Slave (Cities city) { super(city);
    }
}
