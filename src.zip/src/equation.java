public interface equation {
    public int summ(int x,int y);
}
