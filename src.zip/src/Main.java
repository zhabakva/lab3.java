import Agencies.Barge;
import Agencies.Newspaper;
import Constants.Cities;
import Finances.Money;
import Finances.Stock;
import People.*;
import Actions.*;
import Agencies.*;
import Constants.*;
import Finances.*;
public class Main {
    public static void main(String[] args){
        Newspaper Zhaba_news = new Newspaper("Zhaba_news", Cities.DAVILON);
        Newspaper Toad_news = new Newspaper("Toad_news", Cities.PANOPTICON);
        Barge davilon_barge = new Barge("Davilon barge", Cities.DAVILON);
        Barge greenberg_barge = new Barge("Agencies.Barge of Greenberg", Cities.GREENBERG);
        Oligarch Vasya = new Oligarch("Vasya", new Money(140.12), Cities.DAVILON);

        davilon_barge.addCosts(new Stock[]{new Stock("Sber"), new Stock("Apple")});
        greenberg_barge.addCosts(new Stock[]{new Stock("Tinkoff")});
        Slave Andrew = new Slave("Andrew", Cities.DAVILON);
        Oligarch NoName = new Oligarch(new Money(68.4), Cities.GREENBERG);
        NoName.UseTheSlave(davilon_barge, new Stock("Sber"), 3, Andrew);
        Vasya.BuyStock(davilon_barge, new Stock("Sber"), 1);
        NoName.BuyStock(greenberg_barge, new Stock("Apple"), 2);
        Zhaba_news.releaseArticle(davilon_barge, true);
        NoName.BuyStock(davilon_barge, new Stock("Tinkoff"), 2);
        Toad_news.releaseArticle(greenberg_barge, false);


        equation EQ = (x,y) -> x+y;
        System.out.println(EQ.summ(2,3));

        }
    }

